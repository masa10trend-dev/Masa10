const {onCall, HttpsError} = require("firebase-functions/v2/https");
const {onDocumentCreated} = require("firebase-functions/v2/firestore");
const admin = require("firebase-admin");

admin.initializeApp();
const db = admin.firestore();
const FieldValue = admin.firestore.FieldValue;
const now = () => admin.firestore.Timestamp.now();

const TABLE_MINUTES = 20;
const LARGE_TABLE_SIZE = 10;
const SMALL_TABLE_SIZE = 5;
const ENTRY_FEE = 10;
const LARGE_EXTENSION_GOAL = 100;
const SMALL_EXTENSION_GOAL = 50;

function requireAuth(request) {
  if (!request.auth) throw new HttpsError("unauthenticated", "Giriş yapmalısın.");
  return request.auth.uid;
}

exports.joinTable = onCall(async (request) => {
  const uid = requireAuth(request);
  const userRef = db.collection("users").doc(uid);
  const queueRef = db.collection("matchmaking").doc("queue");

  return db.runTransaction(async (tx) => {
    const [userSnap, queueSnap] = await tx.getAll(userRef, queueRef);
    if (!userSnap.exists) throw new HttpsError("failed-precondition", "Kullanıcı profili bulunamadı.");

    const user = userSnap.data() || {};
    const existingTableId = user.activeTableId;
    if (existingTableId) {
      const existingRef = db.collection("tables").doc(existingTableId);
      const existingSnap = await tx.get(existingRef);
      if (existingSnap.exists) {
        const t = existingSnap.data() || {};
        const endAt = t.endAt;
        if (t.status === "waiting" || (endAt && endAt.toMillis() > Date.now())) {
          return {status: t.status, tableId: existingTableId};
        }
      }
      tx.update(userRef, {activeTableId: FieldValue.delete()});
    }

    const coins = Number(user.coins || 0);
    const joinedCount = Number(user.tableJoinCount || 0);
    const fee = joinedCount >= 3 ? ENTRY_FEE : 0;
    if (coins < fee) throw new HttpsError("failed-precondition", `Masaya katılmak için ${fee} jeton gerekli.`);

    const queue = queueSnap.exists ? (queueSnap.data() || {}) : {};
    const members = {...(queue.members || {})};
    if (members[uid]) return {status: "waiting", tableId: queue.tableId || null};
    const currentCount = Object.keys(members).length;
    // 40 kişinin altında küçük masalar, 40 ve üzeri büyük masalar kullanılır.
    // Eşik mevcut bekleme kuyusuna göre değerlendirilir; böylece başlangıçta bekleme süresi kısa tutulur.
    const targetSize = currentCount < 40 ? SMALL_TABLE_SIZE : LARGE_TABLE_SIZE;
    if (currentCount >= targetSize) throw new HttpsError("aborted", "Masa doluyor, tekrar dene.");

    members[uid] = {uid, joinedAt: now(), displayName: user.displayName || user.email?.split("@")[0] || "Kullanıcı"};
    const count = Object.keys(members).length;

    if (fee > 0) {
      tx.update(userRef, {coins: admin.firestore.FieldValue.increment(-fee), tableJoinCount: admin.firestore.FieldValue.increment(1)});
      tx.create(db.collection("coinLedger").doc(), {
        uid, amount: -fee, type: "table_entry", createdAt: now(), description: "4. ve sonraki masa girişi"
      });
    } else {
      tx.update(userRef, {tableJoinCount: admin.firestore.FieldValue.increment(1)});
    }

    if (count < targetSize) {
      tx.set(queueRef, {members, count, updatedAt: now()}, {merge: false});
      tx.update(userRef, {activeTableId: "QUEUE"});
      return {status: "waiting", tableId: null, count};
    }

    const tableRef = db.collection("tables").doc();
    const start = now();
    const end = admin.firestore.Timestamp.fromMillis(start.toMillis() + TABLE_MINUTES * 60 * 1000);
    const topic = "Hayatında tekrar yaşamak isteyeceğin bir gün hangisi?";
    const participantMap = {};
    for (const [memberUid, member] of Object.entries(members)) {
      participantMap[memberUid] = {
        displayName: member.displayName,
        joinedAt: member.joinedAt,
        extensionContributed: 0
      };
      tx.update(db.collection("users").doc(memberUid), {activeTableId: tableRef.id});
    }
    tx.set(tableRef, {
      status: "active",
      topic,
      participants: participantMap,
      participantCount: targetSize,
      startAt: start,
      endAt: end,
      extensionPool: 0,
      extensionGoal: targetSize === SMALL_TABLE_SIZE ? SMALL_EXTENSION_GOAL : LARGE_EXTENSION_GOAL,
      extensionCount: 0,
      createdAt: start
    });
    tx.delete(queueRef);
    return {status: "active", tableId: tableRef.id, count: targetSize};
  });
});

exports.leaveQueue = onCall(async (request) => {
  const uid = requireAuth(request);
  const queueRef = db.collection("matchmaking").doc("queue");
  const userRef = db.collection("users").doc(uid);
  return db.runTransaction(async (tx) => {
    const [queueSnap, userSnap] = await tx.getAll(queueRef, userRef);
    if (!queueSnap.exists) return {ok: true};
    const queue = queueSnap.data() || {};
    const members = {...(queue.members || {})};
    if (members[uid]) delete members[uid];
    if (Object.keys(members).length === 0) tx.delete(queueRef);
    else tx.set(queueRef, {members, count: Object.keys(members).length, updatedAt: now()});
    if (userSnap.exists) tx.update(userRef, {activeTableId: FieldValue.delete()});
    return {ok: true};
  });
});

exports.extendTable = onCall(async (request) => {
  const uid = requireAuth(request);
  const tableId = request.data?.tableId;
  if (!tableId) throw new HttpsError("invalid-argument", "tableId gerekli.");
  const tableRef = db.collection("tables").doc(tableId);
  const userRef = db.collection("users").doc(uid);

  return db.runTransaction(async (tx) => {
    const [tableSnap, userSnap] = await tx.getAll(tableRef, userRef);
    if (!tableSnap.exists) throw new HttpsError("not-found", "Masa bulunamadı.");
    const table = tableSnap.data() || {};
    if (table.status !== "active") throw new HttpsError("failed-precondition", "Bu masa aktif değil.");
    if (!table.participants?.[uid]) throw new HttpsError("permission-denied", "Bu masanın katılımcısı değilsin.");
    if (table.endAt.toMillis() <= Date.now()) throw new HttpsError("failed-precondition", "Masanın süresi doldu.");
    const coins = Number(userSnap.data()?.coins || 0);
    if (coins < 10) throw new HttpsError("failed-precondition", "Uzatmak için 10 jeton gerekli.");

    const extensionGoal = Number(table.extensionGoal || (Number(table.tableSize || 10) === SMALL_TABLE_SIZE ? SMALL_EXTENSION_GOAL : LARGE_EXTENSION_GOAL));
    const newPool = Number(table.extensionPool || 0) + 10;
    const participants = {...(table.participants || {})};
    participants[uid] = {...participants[uid], extensionContributed: Number(participants[uid].extensionContributed || 0) + 10};
    const updates = {
      extensionPool: newPool,
      participants,
      updatedAt: now()
    };
    if (newPool >= extensionGoal) {
      updates.extensionPool = 0;
      updates.extensionCount = admin.firestore.FieldValue.increment(1);
      updates.endAt = admin.firestore.Timestamp.fromMillis(table.endAt.toMillis() + TABLE_MINUTES * 60 * 1000);
    }
    tx.update(userRef, {coins: admin.firestore.FieldValue.increment(-10)});
    tx.create(db.collection("coinLedger").doc(), {uid, amount: -10, type: "table_extension", tableId, createdAt: now(), description: "Masa uzatma katkısı"});
    tx.update(tableRef, updates);
    return {ok: true, pool: updates.extensionPool, extended: newPool >= extensionGoal};
  });
});

exports.togglePostLike = onCall(async (request) => {
  const uid = requireAuth(request);
  const postId = request.data?.postId;
  if (!postId) throw new HttpsError("invalid-argument", "postId gerekli.");
  const postRef = db.collection("posts").doc(postId);
  return db.runTransaction(async (tx) => {
    const snap = await tx.get(postRef);
    if (!snap.exists) throw new HttpsError("not-found", "Gönderi bulunamadı.");
    const data = snap.data() || {};
    const likedBy = Array.isArray(data.likedBy) ? [...data.likedBy] : [];
    const index = likedBy.indexOf(uid);
    if (index >= 0) likedBy.splice(index, 1); else likedBy.push(uid);
    tx.update(postRef, {likedBy, likeCount: likedBy.length});
    return {liked: index < 0, likeCount: likedBy.length};
  });
});



exports.getPublicProfile = onCall(async (request) => {
  requireAuth(request);
  const targetUid = request.data?.uid;
  if (!targetUid) throw new HttpsError("invalid-argument", "uid gerekli.");
  const userSnap = await db.collection("users").doc(targetUid).get();
  if (!userSnap.exists) throw new HttpsError("not-found", "Kullanıcı bulunamadı.");
  const u = userSnap.data() || {};
  const postsSnap = await db.collection("posts").where("uid", "==", targetUid).limit(100).get();
  const followerCount = Number(u.followersCount || 0);
  const followingSnap = await db.collection("users").doc(targetUid).collection("following").limit(500).get();
  const myFollowSnap = await db.collection("users").doc(targetUid).collection("followers").doc(request.auth.uid).get();
  return {displayName: u.displayName || u.email?.split("@")[0] || "Masa10 Kullanıcısı", bio: u.bio || "Masa10'da güzel sohbetlerin peşinde ✨", postCount: postsSnap.size, followers: followerCount, following: followingSnap.size, isFollowing: myFollowSnap.exists};
});

exports.addPostComment = onCall(async (request) => {
  const uid = requireAuth(request);
  const {postId, text} = request.data || {};
  const clean = String(text || "").trim();
  if (!postId || !clean || clean.length > 280) throw new HttpsError("invalid-argument", "Geçerli bir yorum gerekli.");
  const postRef = db.collection("posts").doc(postId);
  const userRef = db.collection("users").doc(uid);
  const commentRef = postRef.collection("comments").doc();
  return db.runTransaction(async (tx) => {
    const [postSnap, userSnap] = await tx.getAll(postRef, userRef);
    if (!postSnap.exists) throw new HttpsError("not-found", "Gönderi bulunamadı.");
    const u = userSnap.data() || {};
    tx.create(commentRef, {uid, displayName: u.displayName || u.email?.split("@")[0] || "Kullanıcı", text: clean, createdAt: now()});
    tx.update(postRef, {commentCount: FieldValue.increment(1)});
    return {ok: true};
  });
});

exports.toggleRepost = onCall(async (request) => {
  const uid = requireAuth(request);
  const postId = request.data?.postId;
  if (!postId) throw new HttpsError("invalid-argument", "postId gerekli.");
  const postRef = db.collection("posts").doc(postId);
  const repostRef = postRef.collection("reposts").doc(uid);
  return db.runTransaction(async (tx) => {
    const snap = await tx.get(postRef);
    if (!snap.exists) throw new HttpsError("not-found", "Gönderi bulunamadı.");
    const repostSnap = await tx.get(repostRef);
    const count = Number(snap.data()?.repostCount || 0);
    if (repostSnap.exists) { tx.delete(repostRef); tx.update(postRef, {repostCount: Math.max(0, count - 1)}); return {reposted: false, repostCount: Math.max(0, count - 1)}; }
    tx.create(repostRef, {uid, createdAt: now()});
    tx.update(postRef, {repostCount: count + 1});
    return {reposted: true, repostCount: count + 1};
  });
});


exports.toggleFollow = onCall(async (request) => {
  const uid = requireAuth(request);
  const targetUid = request.data?.targetUid;
  if (!targetUid || targetUid === uid) throw new HttpsError("invalid-argument", "Geçerli bir kullanıcı gerekli.");
  const meRef = db.collection("users").doc(uid);
  const targetRef = db.collection("users").doc(targetUid);
  const followRef = targetRef.collection("followers").doc(uid);
  const followingRef = meRef.collection("following").doc(targetUid);
  return db.runTransaction(async (tx) => {
    const [meSnap, targetSnap, followSnap] = await tx.getAll(meRef, targetRef, followRef);
    if (!targetSnap.exists) throw new HttpsError("not-found", "Kullanıcı bulunamadı.");
    const following = followSnap.exists;
    if (following) {
      tx.delete(followRef); tx.delete(followingRef);
      tx.update(targetRef, {followersCount: Math.max(0, Number(targetSnap.data()?.followersCount || 0) - 1)});
      return {following: false, followers: Math.max(0, Number(targetSnap.data()?.followersCount || 0) - 1)};
    }
    const me = meSnap.data() || {};
    const followerName = me.displayName || me.email?.split("@")[0] || "Bir kullanıcı";
    tx.create(followRef, {uid, displayName: followerName, createdAt: now()});
    tx.set(followingRef, {uid: targetUid, createdAt: now()});
    tx.update(targetRef, {followersCount: FieldValue.increment(1)});
    tx.set(targetRef.collection("notifications").doc(), {title: "Yeni takipçi", body: `${followerName} seni takip etmeye başladı.`, type: "follow", fromUid: uid, createdAt: now(), read: false});
    return {following: true, followers: Number(targetSnap.data()?.followersCount || 0) + 1};
  });
});



function requireAdmin(request) {
  if (!request.auth || request.auth.token.admin !== true) {
    throw new HttpsError("permission-denied", "Admin yetkisi gerekli.");
  }
  return request.auth.uid;
}

function campaignFromSnap(doc) {
  const d = doc.data() || {};
  return {
    id: doc.id,
    title: d.title || "Masa10",
    body: d.body || "Masa10'da yeni insanlarla tanış, kısa ve gerçek sohbetlere katıl.",
    advertiserName: d.advertiserName || "Masa10",
    icon: d.icon || "✦",
    clickUrl: d.clickUrl || "",
    status: d.status || "draft",
    startAt: d.startAt || null,
    endAt: d.endAt || null,
    durationDays: Number(d.durationDays || 0),
    priceTl: Number(d.priceTl || 0),
    paymentStatus: d.paymentStatus || "not_required",
    productId: d.productId || "",
    orderId: d.orderId || "",
    budget: Number(d.budget || 0),
    spent: Number(d.spent || 0),
    impressions: Number(d.impressions || 0),
    clicks: Number(d.clicks || 0),
    createdAt: d.createdAt || null
  };
}

exports.getActiveSponsoredCampaigns = onCall(async (request) => {
  requireAuth(request);
  const snap = await db.collection("campaigns").where("status", "==", "approved").limit(50).get();
  const current = Date.now();
  return {
    campaigns: snap.docs.map(campaignFromSnap).filter(c => {
      const start = c.startAt?.toMillis ? c.startAt.toMillis() : 0;
      const end = c.endAt?.toMillis ? c.endAt.toMillis() : Number.MAX_SAFE_INTEGER;
      return start <= current && current <= end && (c.budget <= 0 || c.spent < c.budget);
    })
  };
});

// Kullanıcı reklam satın aldıktan sonra başvuru oluşturur. Ödeme bilgisi saklanır;
// üretimde purchaseToken sunucu tarafında Google Play Developer API ile doğrulanmalıdır.
exports.submitSponsoredCampaign = onCall(async (request) => {
  const uid = requireAuth(request);
  const data = request.data || {};
  const plans = {
    "7d": {days: 7, priceTl: 999, productId: "masa10_ad_7d"},
    "30d": {days: 30, priceTl: 1999, productId: "masa10_ad_30d"}
  };
  const planId = String(data.planId || "");
  const plan = plans[planId];
  if (!plan) throw new HttpsError("invalid-argument", "Geçersiz reklam paketi.");
  if (String(data.productId || "") !== plan.productId) throw new HttpsError("invalid-argument", "Ürün paketi eşleşmiyor.");
  const purchaseToken = String(data.purchaseToken || "").trim();
  if (!purchaseToken) throw new HttpsError("invalid-argument", "Ödeme doğrulama bilgisi eksik.");
  const title = String(data.title || "").trim().slice(0, 80);
  const body = String(data.body || "").trim().slice(0, 280);
  const advertiserName = String(data.advertiserName || "").trim().slice(0, 60);
  const clickUrl = String(data.clickUrl || "").trim().slice(0, 500);
  if (!title || !body || !advertiserName) throw new HttpsError("invalid-argument", "Başlık, açıklama ve reklamveren gerekli.");

  const duplicate = await db.collection("campaigns").where("purchaseToken", "==", purchaseToken).limit(1).get();
  if (!duplicate.empty) throw new HttpsError("already-exists", "Bu ödeme daha önce bir reklam başvurusunda kullanılmış.");

  const ref = await db.collection("campaigns").add({
    uid, title, body, advertiserName, icon: "📢", clickUrl,
    planId, durationDays: plan.days, priceTl: plan.priceTl,
    productId: plan.productId, purchaseToken, orderId: String(data.orderId || ""),
    paymentStatus: "pending_verification", status: "pending",
    budget: 0, spent: 0, impressions: 0, clicks: 0,
    createdBy: uid, createdAt: now(), startAt: null, endAt: null
  });
  return {ok: true, id: ref.id, status: "pending"};
});

exports.createSponsoredCampaign = onCall(async (request) => {
  const uid = requireAdmin(request);
  const data = request.data || {};
  const title = String(data.title || "").trim().slice(0, 80);
  const body = String(data.body || "").trim().slice(0, 280);
  const advertiserName = String(data.advertiserName || "").trim().slice(0, 60);
  const icon = String(data.icon || "📢").slice(0, 4);
  const clickUrl = String(data.clickUrl || "").trim().slice(0, 500);
  const budget = Math.max(0, Number(data.budget || 0));
  if (!title || !body || !advertiserName) throw new HttpsError("invalid-argument", "Başlık, açıklama ve reklamveren gerekli.");
  const ref = await db.collection("campaigns").add({
    title, body, advertiserName, icon, clickUrl, budget, spent: 0, impressions: 0, clicks: 0,
    status: "pending", createdBy: uid, createdAt: now(),
    startAt: null, endAt: null, paymentStatus: "not_required", durationDays: 0, priceTl: 0
  });
  return {ok: true, id: ref.id};
});

exports.updateSponsoredCampaignStatus = onCall(async (request) => {
  requireAdmin(request);
  const campaignId = String(request.data?.campaignId || "");
  const status = String(request.data?.status || "");
  if (!campaignId || !["pending", "approved", "paused", "rejected", "completed"].includes(status)) {
    throw new HttpsError("invalid-argument", "Geçerli kampanya ve durum gerekli.");
  }
  const ref = db.collection("campaigns").doc(campaignId);
  const snap = await ref.get();
  if (!snap.exists) throw new HttpsError("not-found", "Kampanya bulunamadı.");
  const d = snap.data() || {};
  const update = {status, updatedAt: now(), updatedBy: request.auth.uid};
  // Süre admin ONAYI ile başlar. Böylece ödeme yapılmış olsa bile onaydan önce reklam süresi yanmaz.
  if (status === "approved" && d.status !== "approved") {
    const days = Number(d.durationDays || 0);
    if (days > 0) {
      const start = Date.now();
      update.startAt = admin.firestore.Timestamp.fromMillis(start);
      update.endAt = admin.firestore.Timestamp.fromMillis(start + days * 86400000);
      update.paymentStatus = "verified_by_admin";
    }
  }
  await ref.update(update);
  return {ok: true};
});

exports.listSponsoredCampaigns = onCall(async (request) => {
  requireAdmin(request);
  const snap = await db.collection("campaigns").orderBy("createdAt", "desc").limit(100).get();
  const current = Date.now();
  const updates = [];
  const campaigns = snap.docs.map(doc => {
    const c = campaignFromSnap(doc);
    if (c.status === "approved" && c.endAt?.toMillis && c.endAt.toMillis() < current) {
      updates.push(doc.ref.update({status: "completed", updatedAt: now()}));
      c.status = "completed";
    }
    return c;
  });
  await Promise.all(updates);
  return {campaigns};
});

exports.logSponsoredImpression = onCall(async (request) => {
  requireAuth(request);
  const campaignId = String(request.data?.campaignId || "");
  if (!campaignId) throw new HttpsError("invalid-argument", "campaignId gerekli.");
  const ref = db.collection("campaigns").doc(campaignId);
  const snap = await ref.get();
  if (!snap.exists || snap.data()?.status !== "approved") throw new HttpsError("failed-precondition", "Kampanya aktif değil.");
  const d = snap.data() || {};
  const end = d.endAt?.toMillis ? d.endAt.toMillis() : Number.MAX_SAFE_INTEGER;
  if (Date.now() > end) throw new HttpsError("failed-precondition", "Kampanyanın süresi doldu.");
  await ref.update({impressions: FieldValue.increment(1)});
  return {ok: true};
});

exports.logSponsoredClick = onCall(async (request) => {
  requireAuth(request);
  const campaignId = String(request.data?.campaignId || "");
  if (!campaignId) throw new HttpsError("invalid-argument", "campaignId gerekli.");
  const ref = db.collection("campaigns").doc(campaignId);
  const snap = await ref.get();
  if (!snap.exists || snap.data()?.status !== "approved") throw new HttpsError("failed-precondition", "Kampanya aktif değil.");
  const d = snap.data() || {};
  const end = d.endAt?.toMillis ? d.endAt.toMillis() : Number.MAX_SAFE_INTEGER;
  if (Date.now() > end) throw new HttpsError("failed-precondition", "Kampanyanın süresi doldu.");
  await ref.update({clicks: FieldValue.increment(1)});
  return {ok: true};
});

exports.createDefaultMasa10Campaign = onCall(async (request) => {
  requireAdmin(request);
  const existing = await db.collection("campaigns").where("advertiserName", "==", "Masa10").limit(1).get();
  if (!existing.empty) return {ok: true, id: existing.docs[0].id, existed: true};
  const ref = await db.collection("campaigns").add({
    title: "Masa10'a katıl ✨",
    body: "10 kişi. 20 dakika. Gerçek sohbet. Keşfet'te konuş, masada tanış.",
    advertiserName: "Masa10", icon: "✦", clickUrl: "", budget: 0, spent: 0, impressions: 0, clicks: 0,
    status: "approved", createdBy: request.auth.uid, createdAt: now(), startAt: now(), endAt: admin.firestore.Timestamp.fromMillis(Date.now() + 3650 * 86400000),
    paymentStatus: "not_required", durationDays: 3650, priceTl: 0
  });
  return {ok: true, id: ref.id, existed: false};
});

exports.sendAdminNotification = onCall(async (request) => {
  if (!request.auth || request.auth.token.admin !== true) throw new HttpsError("permission-denied", "Admin yetkisi gerekli.");
  const {title, body, topic} = request.data || {};
  if (!title || !body) throw new HttpsError("invalid-argument", "title ve body gerekli.");
  await db.collection("adminNotifications").add({title, body, topic: topic || "all", createdAt: now(), createdBy: request.auth.uid});
  return {ok: true};
});

exports.onNewUser = onDocumentCreated("users/{uid}", async (event) => {
  const uid = event.params.uid;
  const ref = db.collection("users").doc(uid);
  const snap = await ref.get();
  if (!snap.exists) return null;
  const data = snap.data() || {};
  if (data.coins !== undefined) return null;
  await ref.set({coins: 30, tableJoinCount: 0, createdAt: data.createdAt || now()}, {merge: true});
  await db.collection("coinLedger").add({uid, amount: 30, type: "signup_bonus", createdAt: now(), description: "Kayıt başlangıç bonusu"});
  return null;
});
