# Masa10 v10 – Keşfet Reklam Satışı

Bu sürümde Keşfet reklam akışı genişletildi.

## Reklam paketleri
- 1 Hafta: 999 TL (`masa10_ad_7d`)
- 1 Ay: 1999 TL (`masa10_ad_30d`)

## Akış
1. Kullanıcı Keşfet'te **📢 Reklamını Ver** butonuna basar.
2. 1 hafta / 1 ay paketini seçer.
3. Reklamveren adı, başlık, açıklama ve isteğe bağlı bağlantıyı girer.
4. Google Play ödeme ekranından ödeme yapar.
5. Başvuru Firebase `campaigns` koleksiyonuna `pending` olarak düşer.
6. Admin Paneli'nden reklam incelenir ve onaylanır.
7. **Onay anında** reklam süresi başlar.
8. `endAt` dolunca `getActiveSponsoredCampaigns` reklamı aktif sonuçlardan çıkarır; reklam Keşfet'te otomatik görünmez.

## Önemli yayın ayarları
Google Play Console'da şu tek seferlik ürünler oluşturulmalıdır:
- `masa10_ad_7d` → 999 TL (Türkiye)
- `masa10_ad_30d` → 1999 TL (Türkiye)

Ödeme gerçek üretimde kullanılmadan önce Google Play purchase token'ın Cloud Function tarafında Google Play Developer API ile doğrulanması yapılmalıdır. Şu sürüm token'ı kampanyaya kaydeder ve admin incelemesini bekletir; sunucu doğrulaması üretime çıkmadan tamamlanmalıdır.

## Not
Firebase Storage ile görsel yükleme bu v10 değişikliğinin konusu değildir; reklam formundaki metin/link akışı hazırdır. Görsel yükleme ayrıca Storage/Blaze yapılandırması gerektirir.
