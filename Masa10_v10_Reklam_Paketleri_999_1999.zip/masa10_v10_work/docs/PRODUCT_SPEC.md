# Masa10 — Ürün sözleşmesi

## Ekonomi
- İlk 3 masa ücretsiz.
- 4. masadan itibaren normal kullanıcı giriş ücreti 10 jeton.
- VIP masa girişleri ücretsiz.
- Masa uzatma: kişi başı 10 jeton; toplam 100 jeton.
- Özel sohbet açma: 30 jeton; ödeyen taraf açar.
- VIP: 399 TL/ay; giriş yapılan gün +20 jeton; 1 ücretsiz özel sohbet açma/gün; 10 sesli mesaj/gün (20 sn); reklamsız; 3 fotoğraf/masa.
- Normal kullanıcı: 1 fotoğraf/masa; sesli mesaj yok.
- Ödüllü reklam: +5 jeton, günde 5.
- Referral: iki tarafa 10'ar jeton; davet edilen kişi ilk masa katılımını tamamlayınca.

## Hediyeler
- Çay: 10 jeton
- Gül: 20 jeton
- Diğer hediyeler admin panelinden yönetilebilir.

## Masa
- 10 kişi
- 20 dakika
- Konu/prompt
- Gerçek zamanlı mesaj
- Mesaj beğenisi
- Süre sonunda kapanış
- 100/100 katkı tamamlanınca +20 dakika

## Güvenlik
- Firebase Authentication
- Admin custom claims
- Hassas admin işlemleri Cloud Functions/Admin SDK üzerinden
- Audit log
- Rate limit / abuse prevention
- Jeton bakiyesi production'da doğrudan client tarafından değiştirilemez; ledger + transaction/function kullanılacak.

## Türkiye Akışı
- Ana navigasyonda "Türkiye" sekmesi bulunur.
- Kullanıcılar en fazla 280 karakterlik kısa söz, düşünce veya soru paylaşabilir.
- Akış tüm giriş yapmış kullanıcılar tarafından görülebilir.
- Gönderiler en yeni üstte olacak şekilde listelenir.
- Kullanıcılar gönderileri beğenebilir/beğeniyi kaldırabilir.
- Beğeni işlemi Cloud Function üzerinden sunucu tarafında yapılır.
- İlk sürümde yorum/repost/hashtag yoktur; sonraki sürümlerde eklenebilir.

### Keşfet yenilemesi
- Ana navigasyondaki “Türkiye” sekmesi “Keşfet” olarak adlandırıldı.
- Keşfet içinde Yeni, Popüler ve Trendler sekmeleri bulunur.
- Gönderi arama alanı eklendi; metin, kullanıcı adı ve hashtag üzerinden filtreleme yapılır.
- Trendler hashtag kullanımına göre gösterilir ve etikete dokununca ilgili akış açılır.
- Gönderi kartları profil, hashtag, beğeni, yorum ve repost etkileşimlerine odaklanan daha modern bir tasarıma sahiptir.
- Boş arama/akış durumları için özel durum ekranı bulunur.

### Alt menü sosyal navigasyon
- Alt menü 5 sekme: Masa, Keşfet, Mesajlar, Bildirimler, Profil.
- Bildirimler Profil içine gömülmez; ayrı bir ana navigasyon sekmesidir.
- Okunmamış bildirim varsa Bildirimler ikonunda sayı rozeti gösterilir.
- Keşfet sekmesi Türkiye adının yerine kullanılır.
