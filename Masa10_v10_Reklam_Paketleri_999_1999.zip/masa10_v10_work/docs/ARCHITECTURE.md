# Masa10 — Teknik mimari

Android:
- Kotlin 2.4.20
- Jetpack Compose
- Firebase Auth / Firestore / FCM
- `com.masa10.app`

Backend:
- Firestore
- Cloud Functions
- FCM
- Storage daha sonra Blaze planı açıldığında
- Play Billing ve AdMob production aşamasında

Admin:
- Ayrı web paneli
- Firebase Authentication
- `admin` / `moderator` custom claims
- Server-side Functions/Admin SDK
- 2FA ve audit log

Üretim sırası:
1. Çalışan Android temel uygulama
2. Gerçek masa/eşleştirme
3. Chat + timer
4. Coin ledger + extension
5. Match/private chat
6. Gifts
7. VIP / Billing
8. Ads / referral
9. Moderation
10. Admin paneli
11. Production security rules
12. Closed test + gerçek cihaz testi
