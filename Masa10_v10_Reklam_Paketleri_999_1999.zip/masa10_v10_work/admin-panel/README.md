# Masa10 Admin — Reklam Yönetimi

Bu panel Masa10 Keşfet için sponsorlu reklamları yönetir.

## Ne yapar?
- Masa10 ev reklamını yayınlar.
- Sponsor kampanyası oluşturur.
- Kampanyayı onaylar/durdurur/reddeder.
- Gösterim, tıklama ve CTR gösterir.
- Android uygulaması onaylı kampanyaları Keşfet'te üstte ve 10 organik gönderide bir reklam slotunda kullanır.

## Güvenlik
Panel Firebase Authentication ile giriş yapar. Cloud Functions reklam yönetimi çağrılarını `admin=true` custom claim'i olan hesaplarla sınırlar.

İlk admin hesabına custom claim vermek için Firebase Admin SDK/Cloud Shell üzerinden bir kere şu kod çalıştırılmalıdır:

```js
const admin = require('firebase-admin');
admin.initializeApp();
admin.auth().setCustomUserClaims('KULLANICI_UID', {admin: true});
```

UID, Firebase Console > Authentication > Users ekranından alınabilir. Claim verildikten sonra admin hesabından çıkış yapıp tekrar giriş yapın.

> Not: Bu repo canlı reklam ID'sini içermez. Android uygulamasında geliştirme sırasında Google'ın resmi native test ID'si kullanılır. Yayına çıkmadan önce AdMob App ID ve Native Ad Unit ID, AdMob hesabındaki gerçek ID'lerle değiştirilmelidir.
