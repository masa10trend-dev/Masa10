package com.masa10.app

import android.Manifest
import android.os.Build
import android.os.Bundle
import android.content.Intent
import android.net.Uri
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.FrameLayout
import android.widget.TextView
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import com.android.billingclient.api.*
import android.app.Activity
import com.google.android.gms.ads.AdLoader
import com.google.android.gms.ads.AdRequest
import com.google.android.gms.ads.MobileAds
import com.google.android.gms.ads.nativead.MediaView
import com.google.android.gms.ads.nativead.NativeAd
import com.google.android.gms.ads.nativead.NativeAdOptions
import com.google.android.gms.ads.nativead.NativeAdView
import com.google.firebase.Timestamp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.*
import com.google.firebase.functions.FirebaseFunctions
import com.google.firebase.messaging.FirebaseMessaging
import kotlinx.coroutines.delay
import java.util.Date

private val Bg = Color(0xFF070A12)
private val Card = Color(0xFF101522)
private val Purple = Color(0xFF8B5CF6)
private val Pink = Color(0xFFEC4899)
private val Orange = Color(0xFFF97316)
private val Gold = Color(0xFFF5C542)
private val TextMain = Color(0xFFF5F7FB)
private val TextMuted = Color(0xFF9AA4B2)

class MainActivity : ComponentActivity() {
    private lateinit var adBillingManager: AdBillingManager
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) {}

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (Build.VERSION.SDK_INT >= 33) notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        MobileAds.initialize(this) {}
        adBillingManager = AdBillingManager(this)
        FirebaseMessaging.getInstance().token.addOnSuccessListener { token ->
            FirebaseAuth.getInstance().currentUser?.uid?.let { uid ->
                FirebaseFirestore.getInstance().collection("users").document(uid)
                    .update("fcmToken", token)
            }
        }
        setContent { Masa10App(adBillingManager) }
    }
}

@Composable
fun Masa10App(adBillingManager: AdBillingManager) {
    var page by remember { mutableStateOf("home") }
    var selectedProfileUid by remember { mutableStateOf<String?>(null) }
    var unreadNotifications by remember { mutableIntStateOf(0) }
    var signedIn by remember { mutableStateOf(FirebaseAuth.getInstance().currentUser != null) }
    val currentUid = FirebaseAuth.getInstance().currentUser?.uid
    DisposableEffect(currentUid) {
        if (currentUid == null) { onDispose { } } else {
            val reg = FirebaseFirestore.getInstance().collection("users").document(currentUid)
                .collection("notifications").whereEqualTo("read", false).limit(50)
                .addSnapshotListener { snap, _ -> unreadNotifications = snap?.size() ?: 0 }
            onDispose { reg.remove() }
        }
    }
    MaterialTheme(colorScheme = darkColorScheme(primary = Purple, secondary = Pink, background = Bg, surface = Card)) {
        Surface(color = Bg, modifier = Modifier.fillMaxSize()) {
            if (!signedIn) AuthScreen { signedIn = true }
            else Column(Modifier.fillMaxSize()) {
                Box(Modifier.weight(1f)) {
                    AnimatedContent(page, label = "page") { current ->
                        when (current) {
                            "home" -> HomeScreen(onJoin = { page = "table" }, onCoins = { page = "coins" }, onProfile = { page = "profile" })
                            "turkiye" -> TurkiyeFeedScreen(adBillingManager = adBillingManager, onProfile = { selectedProfileUid = it; page = "userProfile" }, onNotifications = { page = "notifications" })
                            "userProfile" -> UserProfileScreen(uid = selectedProfileUid ?: "", onBack = { page = "turkiye" })
                            "notifications" -> NotificationsScreen(onBack = { page = "home" })
                            "messages" -> MessagesScreen(onBack = { page = "home" })
                            "table" -> TableScreen(onBack = { page = "home" })
                            "coins" -> CoinsScreen(onBack = { page = "home" })
                            "profile" -> ProfileScreen(onBack = { page = "home" })
                            else -> HomeScreen({ page = "table" }, { page = "coins" }, { page = "profile" })
                        }
                    }
                }
                NavigationBar(containerColor = Card) {
                    NavigationBarItem(page == "home", { page = "home" }, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Masa") })
                    NavigationBarItem(page == "turkiye", { page = "turkiye" }, icon = { Icon(Icons.Default.Explore, null) }, label = { Text("Keşfet") })
                    NavigationBarItem(page == "messages", { page = "messages" }, icon = { Icon(Icons.Default.ChatBubbleOutline, null) }, label = { Text("Mesajlar") })
                    NavigationBarItem(page == "notifications", { page = "notifications" }, icon = {
                        BadgedBox(badge = { if (unreadNotifications > 0) Badge { Text(if (unreadNotifications > 99) "99+" else unreadNotifications.toString()) } }) {
                            Icon(Icons.Default.NotificationsNone, null)
                        }
                    }, label = { Text("Bildirimler") })
                    NavigationBarItem(page == "profile", { page = "profile" }, icon = { Icon(Icons.Default.Person, null) }, label = { Text("Profil") })
                }
            }
        }
    }
}

@Composable
private fun AuthScreen(onSignedIn: () -> Unit) {
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var register by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    Column(Modifier.fillMaxSize().padding(28.dp), verticalArrangement = Arrangement.Center) {
        Text("MASA10", fontSize = 42.sp, fontWeight = FontWeight.Black, color = TextMain)
        Text("10 kişi. 20 dakika. Gerçek sohbet.", color = TextMuted, fontSize = 15.sp)
        Spacer(Modifier.height(28.dp))
        OutlinedTextField(email, { email = it }, label = { Text("E-posta") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(password, { password = it }, label = { Text("Şifre") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
        Spacer(Modifier.height(18.dp))
        Button(onClick = {
            val task = if (register) FirebaseAuth.getInstance().createUserWithEmailAndPassword(email.trim(), password)
            else FirebaseAuth.getInstance().signInWithEmailAndPassword(email.trim(), password)
            task.addOnSuccessListener {
                val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return@addOnSuccessListener
                FirebaseFirestore.getInstance().collection("users").document(uid).set(
                    mapOf("email" to email.trim(), "createdAt" to FieldValue.serverTimestamp()), SetOptions.merge()
                ).addOnCompleteListener { onSignedIn() }
            }.addOnFailureListener { error = it.localizedMessage }
        }, Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Purple)) {
            Text(if (register) "Hesap Oluştur" else "Giriş Yap")
        }
        TextButton({ register = !register }) { Text(if (register) "Zaten hesabım var" else "Yeni hesap oluştur") }
        error?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp) }
    }
}

@Composable
private fun HomeScreen(onJoin: () -> Unit, onCoins: () -> Unit, onProfile: () -> Unit) {
    val uid = FirebaseAuth.getInstance().currentUser?.uid
    var coins by remember { mutableIntStateOf(0) }
    DisposableEffect(uid) {
        if (uid == null) return@DisposableEffect onDispose { }
        val reg = FirebaseFirestore.getInstance().collection("users").document(uid).addSnapshotListener { snap, _ ->
            coins = (snap?.getLong("coins") ?: 0L).toInt()
        }
        onDispose { reg.remove() }
    }
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.weight(1f)) { Text("Masa10", fontSize = 30.sp, fontWeight = FontWeight.Black); Text("Bugün kiminle tanışacaksın?", color = TextMuted) }
            Surface(shape = RoundedCornerShape(18.dp), color = Card) { Row(Modifier.padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) { Text("🪙", fontSize = 18.sp); Spacer(Modifier.width(5.dp)); Text("$coins", color = Gold, fontWeight = FontWeight.Bold) } }
        }
        Spacer(Modifier.height(26.dp))
        Box(Modifier.fillMaxWidth().height(220.dp).clip(RoundedCornerShape(28.dp)).background(Brush.linearGradient(listOf(Purple, Pink, Orange)))) {
            Column(Modifier.padding(24.dp)) {
                Text("YENİ MASA", color = Color.White, fontWeight = FontWeight.Bold)
                Text("10 kişi.\n20 dakika.\nGerçek sohbet.", color = Color.White, fontSize = 28.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
                Button(onClick = onJoin, colors = ButtonDefaults.buttonColors(containerColor = Color.White, contentColor = Bg)) { Text("Masaya Katıl  →") }
            }
        }
        Spacer(Modifier.height(18.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            HomeCard("🪙", "Jeton Kazan", "Reklamla +5", Modifier.weight(1f), onCoins)
            HomeCard("👤", "Profil", "Eşleşmelerin", Modifier.weight(1f), onProfile)
        }
        Spacer(Modifier.height(20.dp)); Text("Bugünün konusu", color = TextMuted, fontSize = 13.sp); Spacer(Modifier.height(6.dp))
        Text("“Hayatında tekrar yaşamak isteyeceğin bir gün hangisi?”", fontSize = 18.sp, fontWeight = FontWeight.SemiBold)
    }
}

@Composable
private fun HomeCard(icon: String, title: String, subtitle: String, modifier: Modifier, onClick: () -> Unit) {
    Surface(modifier = modifier.clickable(onClick = onClick), color = Card, shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(16.dp)) { Text(icon, fontSize = 24.sp); Spacer(Modifier.height(8.dp)); Text(title, fontWeight = FontWeight.Bold); Text(subtitle, color = TextMuted, fontSize = 12.sp) }
    }
}


@Composable
private fun TurkiyeFeedScreen(adBillingManager: AdBillingManager, onProfile: (String) -> Unit, onNotifications: () -> Unit) {
    val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return
    val db = FirebaseFirestore.getInstance()
    val functions = FirebaseFunctions.getInstance()
    var text by remember { mutableStateOf("") }
    var posts by remember { mutableStateOf<List<FeedPost>>(emptyList()) }
    var campaigns by remember { mutableStateOf<List<SponsoredCampaign>>(emptyList()) }
    var posting by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }
    var tab by remember { mutableStateOf("latest") }
    var hashtag by remember { mutableStateOf<String?>(null) }
    var commentPost by remember { mutableStateOf<String?>(null) }
    var search by remember { mutableStateOf("") }
    var isVip by remember { mutableStateOf(false) }
    var showAdDialog by remember { mutableStateOf(false) }

    DisposableEffect(Unit) {
        val reg = db.collection("posts").orderBy("createdAt", Query.Direction.DESCENDING).limit(100)
            .addSnapshotListener { snap, e ->
                if (e != null) { error = e.localizedMessage; return@addSnapshotListener }
                posts = snap?.documents?.map { d ->
                    val data = d.data ?: emptyMap()
                    val likedBy = (data["likedBy"] as? List<*>)?.filterIsInstance<String>() ?: emptyList()
                    FeedPost(d.id, data["uid"] as? String ?: "", data["displayName"] as? String ?: "Masa10 Kullanıcısı",
                        data["text"] as? String ?: "", data["createdAt"] as? Timestamp,
                        (data["likeCount"] as? Long)?.toInt() ?: 0, uid in likedBy,
                        (data["commentCount"] as? Long)?.toInt() ?: 0, (data["repostCount"] as? Long)?.toInt() ?: 0,
                        (data["hashtags"] as? List<*>)?.filterIsInstance<String>() ?: emptyList())
                } ?: emptyList()
            }
        onDispose { reg.remove() }
    }

    DisposableEffect(uid) {
        val userReg = db.collection("users").document(uid).addSnapshotListener { snap, _ ->
            isVip = snap?.getBoolean("isVip") == true
        }
        functions.getHttpsCallable("getActiveSponsoredCampaigns").call()
            .addOnSuccessListener { result ->
                val root = result.data as? Map<*, *> ?: return@addOnSuccessListener
                val list = root["campaigns"] as? List<*> ?: emptyList<Any>()
                campaigns = list.mapNotNull { raw ->
                    val m = raw as? Map<*, *> ?: return@mapNotNull null
                    SponsoredCampaign(
                        id = m["id"] as? String ?: return@mapNotNull null,
                        title = m["title"] as? String ?: "Masa10",
                        body = m["body"] as? String ?: "",
                        advertiserName = m["advertiserName"] as? String ?: "Masa10",
                        icon = m["icon"] as? String ?: "📢",
                        clickUrl = m["clickUrl"] as? String ?: ""
                    )
                }
            }
        onDispose { userReg.remove() }
    }

    val visiblePosts = remember(posts, tab, hashtag, search) {
        var list = posts
        if (hashtag != null) list = list.filter { hashtag!!.removePrefix("#").lowercase() in it.hashtags.map(String::lowercase) }
        if (search.isNotBlank()) {
            val q = search.trim().lowercase()
            list = list.filter { it.text.lowercase().contains(q) || it.displayName.lowercase().contains(q) || it.hashtags.any { tag -> tag.lowercase().contains(q.removePrefix("#")) } }
        }
        if (tab == "popular") list.sortedByDescending { it.likeCount + it.commentCount * 2 + it.repostCount * 2 } else list
    }
    val trends = remember(posts) {
        posts.flatMap { it.hashtags }.groupingBy { it.lowercase() }.eachCount().entries.sortedByDescending { it.value }.take(8)
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text("Keşfet", fontSize = 30.sp, fontWeight = FontWeight.Black)
                Text("Masa10'da gündem burada akıyor", color = TextMuted, fontSize = 13.sp)
            }
            Button(onClick = { showAdDialog = true }, colors = ButtonDefaults.buttonColors(containerColor = Orange), shape = RoundedCornerShape(14.dp), contentPadding = PaddingValues(horizontal = 12.dp, vertical = 8.dp)) {
                Text("📢 Reklamını Ver", fontSize = 12.sp, fontWeight = FontWeight.Black)
            }
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onNotifications) { Icon(Icons.Default.NotificationsNone, null, tint = TextMuted) }
                Surface(shape = CircleShape, color = Purple.copy(alpha = .18f)) { Text("✦", Modifier.padding(10.dp), fontSize = 20.sp, color = Purple) }
            }
        }
        Surface(Modifier.fillMaxWidth().padding(horizontal = 14.dp), color = Card, shape = RoundedCornerShape(18.dp)) {
            Row(Modifier.padding(horizontal = 14.dp, vertical = 5.dp), verticalAlignment = Alignment.CenterVertically) {
                Icon(Icons.Default.Search, null, tint = TextMuted)
                Spacer(Modifier.width(8.dp))
                OutlinedTextField(search, { search = it }, modifier = Modifier.weight(1f), placeholder = { Text("Keşfet'te ara…") }, singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(unfocusedBorderColor = Color.Transparent, focusedBorderColor = Color.Transparent))
            }
        }
        Row(Modifier.padding(horizontal = 14.dp, vertical = 10.dp), horizontalArrangement = Arrangement.spacedBy(7.dp)) {
            listOf("latest" to "✨ Yeni", "popular" to "🔥 Popüler", "trends" to "📈 Trendler").forEach { (key, label) ->
                FilterChip(selected = tab == key, onClick = { tab = key; hashtag = null }, label = { Text(label, fontWeight = FontWeight.SemiBold) })
            }
        }
        if (tab == "trends") {
            LazyColumn(Modifier.fillMaxSize().padding(horizontal = 14.dp), verticalArrangement = Arrangement.spacedBy(10.dp), contentPadding = PaddingValues(bottom = 24.dp)) {
                item {
                    Surface(Modifier.fillMaxWidth(), shape = RoundedCornerShape(24.dp), color = Card) {
                        Column(Modifier.padding(18.dp)) {
                            Text("🔥 Gündem şimdi burada", fontSize = 21.sp, fontWeight = FontWeight.Black)
                            Text("Masa10'da en çok konuşulan etiketler", color = TextMuted, fontSize = 12.sp)
                        }
                    }
                }
                items(trends) { item ->
                    Surface(Modifier.fillMaxWidth().clickable { hashtag = "#${item.key}"; tab = "latest" }, color = Card, shape = RoundedCornerShape(18.dp)) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(42.dp).clip(CircleShape).background(Purple.copy(alpha = .18f)), contentAlignment = Alignment.Center) { Text("#", color = Purple, fontWeight = FontWeight.Black) }
                            Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text("#${item.key}", fontWeight = FontWeight.Bold, fontSize = 16.sp); Text("${item.value} paylaşım", color = TextMuted, fontSize = 12.sp) }
                            Icon(Icons.Default.ChevronRight, null, tint = TextMuted)
                        }
                    }
                }
            }
            return@Column
        }
        if (hashtag != null) {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 7.dp), verticalAlignment = Alignment.CenterVertically) {
                Text("${hashtag}", color = Purple, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                TextButton(onClick = { hashtag = null }) { Text("Temizle") }
            }
        }
        Surface(Modifier.fillMaxWidth().padding(horizontal = 14.dp, vertical = 2.dp), color = Card, shape = RoundedCornerShape(22.dp)) {
            Column(Modifier.padding(15.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(42.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Purple, Pink))), contentAlignment = Alignment.Center) { Text("M", color = Color.White, fontWeight = FontWeight.Black) }
                    Spacer(Modifier.width(10.dp)); Text("Masa10'da ne konuşuluyor?", color = TextMuted, fontSize = 14.sp)
                }
                Spacer(Modifier.height(10.dp))
                OutlinedTextField(text, { if (it.length <= 280) text = it }, modifier = Modifier.fillMaxWidth(), placeholder = { Text("Bir düşünce, soru veya gündem bırak…") }, minLines = 2, maxLines = 5)
                Row(Modifier.fillMaxWidth().padding(top = 9.dp), verticalAlignment = Alignment.CenterVertically) {
                    Text("${text.length}/280", color = if (text.length > 250) Orange else TextMuted, fontSize = 11.sp, modifier = Modifier.weight(1f))
                    Button(enabled = text.trim().isNotEmpty() && !posting, onClick = {
                        posting = true; error = null
                        val user = FirebaseAuth.getInstance().currentUser
                        val ref = db.collection("posts").document()
                        val name = user?.displayName?.takeIf { it.isNotBlank() } ?: user?.email?.substringBefore("@") ?: "Masa10 Kullanıcısı"
                        val tags = Regex("#[A-Za-zÇĞİÖŞÜçğıöşü0-9_]+", RegexOption.IGNORE_CASE).findAll(text).map { it.value.removePrefix("#").lowercase() }.distinct().take(8).toList()
                        ref.set(mapOf("uid" to uid, "displayName" to name.take(40), "text" to text.trim(), "createdAt" to FieldValue.serverTimestamp(), "likeCount" to 0, "likedBy" to emptyList<String>(), "commentCount" to 0, "repostCount" to 0, "hashtags" to tags))
                            .addOnSuccessListener { text = ""; posting = false }.addOnFailureListener { error = it.localizedMessage; posting = false }
                    }, colors = ButtonDefaults.buttonColors(containerColor = Purple), shape = RoundedCornerShape(14.dp)) { Text(if (posting) "Paylaşılıyor…" else "Paylaş", fontWeight = FontWeight.Bold) }
                }
            }
        }
        error?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp, modifier = Modifier.padding(12.dp)) }
        LazyColumn(Modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(9.dp), contentPadding = PaddingValues(top = 9.dp, bottom = 24.dp)) {
            item {
                if (!isVip) {
                    val topCampaign = campaigns.firstOrNull()
                    if (topCampaign != null) SponsoredCampaignCard(topCampaign) else HouseSponsoredCard(onClick = { })
                }
            }
            if (visiblePosts.isEmpty()) item { Surface(Modifier.fillMaxWidth().padding(14.dp), color = Card, shape = RoundedCornerShape(22.dp)) { Column(Modifier.padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) { Text("✨", fontSize = 34.sp); Spacer(Modifier.height(8.dp)); Text("Henüz burada bir şey yok", fontWeight = FontWeight.Bold); Text("İlk paylaşımı sen başlat.", color = TextMuted, fontSize = 12.sp) } } }
            itemsIndexed(visiblePosts, key = { _, it -> it.id }) { index, post ->
                FeedPostCard(post, onProfile = { onProfile(post.uid) }, onHashtag = { hashtag = it; tab = "latest" },
                    onLike = { functions.getHttpsCallable("togglePostLike").call(mapOf("postId" to post.id)) },
                    onComment = { commentPost = post.id },
                    onRepost = { functions.getHttpsCallable("toggleRepost").call(mapOf("postId" to post.id)) })
                if (!isVip && (index + 1) % 10 == 0) {
                    val slot = (index + 1) / 10
                    if (slot % 2 == 1) {
                        val campaign = campaigns.firstOrNull()
                        if (campaign != null) SponsoredCampaignCard(campaign) else NativeAdCard()
                    } else {
                        NativeAdCard()
                    }
                }
            }
        }
    }
    commentPost?.let { postId -> CommentSheet(postId = postId, onClose = { commentPost = null }) }
    if (showAdDialog) { AdCampaignDialog(adBillingManager = adBillingManager, onClose = { showAdDialog = false }) }
}

private data class AdPlan(val id: String, val title: String, val days: Int, val priceTl: Int, val productId: String)

class AdBillingManager(private val activity: Activity) : PurchasesUpdatedListener {
    private val billingClient = BillingClient.newBuilder(activity)
        .setListener(this)
        .enablePendingPurchases(PendingPurchasesParams.newBuilder().enableOneTimeProducts().build())
        .build()
    private val products = mutableMapOf<String, ProductDetails>()
    private var pendingProductId: String? = null
    private var success: ((String, String, String) -> Unit)? = null
    private var failure: ((String) -> Unit)? = null

    init { connect() }
    private fun connect() {
        if (billingClient.isReady) return
        billingClient.startConnection(object : BillingClientStateListener {
            override fun onBillingSetupFinished(result: BillingResult) { if (result.responseCode == BillingClient.BillingResponseCode.OK) queryProducts() }
            override fun onBillingServiceDisconnected() {}
        })
    }
    private fun queryProducts() {
        val params = QueryProductDetailsParams.newBuilder().setProductList(listOf(
            QueryProductDetailsParams.Product.newBuilder().setProductId("masa10_ad_7d").setProductType(BillingClient.ProductType.INAPP).build(),
            QueryProductDetailsParams.Product.newBuilder().setProductId("masa10_ad_30d").setProductType(BillingClient.ProductType.INAPP).build()
        )).build()
        billingClient.queryProductDetailsAsync(params) { result, data ->
            if (result.responseCode == BillingClient.BillingResponseCode.OK) data.productDetailsList.forEach { products[it.productId] = it }
        }
    }
    fun buy(productId: String, onSuccess: (productId: String, token: String, orderId: String) -> Unit, onError: (String) -> Unit) {
        pendingProductId = productId; success = onSuccess; failure = onError
        if (!billingClient.isReady) { connect(); onError("Google Play ödeme bağlantısı hazırlanıyor. Tekrar deneyin."); return }
        val product = products[productId]
        if (product == null) { queryProducts(); onError("Reklam paketi şu an Google Play'de bulunamadı. Play Console ürünlerini ekledikten sonra tekrar deneyin."); return }
        val offer = product.oneTimePurchaseOfferDetailsList?.firstOrNull()
        val builder = BillingFlowParams.ProductDetailsParams.newBuilder().setProductDetails(product)
        offer?.offerToken?.let { builder.setOfferToken(it) }
        val flow = BillingFlowParams.newBuilder().setProductDetailsParamsList(listOf(builder.build())).build()
        val result = billingClient.launchBillingFlow(activity, flow)
        if (result.responseCode != BillingClient.BillingResponseCode.OK) onError(result.debugMessage)
    }
    override fun onPurchasesUpdated(result: BillingResult, purchases: MutableList<Purchase>?) {
        if (result.responseCode != BillingClient.BillingResponseCode.OK || purchases.isNullOrEmpty()) { if (result.responseCode != BillingClient.BillingResponseCode.USER_CANCELED) failure?.invoke(result.debugMessage); return }
        purchases.filter { it.purchaseState == Purchase.PurchaseState.PURCHASED }.forEach { purchase ->
            val pid = purchase.products.firstOrNull() ?: pendingProductId ?: return@forEach
            success?.invoke(pid, purchase.purchaseToken, purchase.orderId ?: "")
            billingClient.consumeAsync(ConsumeParams.newBuilder().setPurchaseToken(purchase.purchaseToken).build()) { _, _ -> }
        }
    }
}

@Composable
private fun AdCampaignDialog(adBillingManager: AdBillingManager, onClose: () -> Unit) {
    val functions = FirebaseFunctions.getInstance()
    val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return
    var selected by remember { mutableStateOf(AdPlan("7d", "1 Hafta", 7, 999, "masa10_ad_7d")) }
    var advertiser by remember { mutableStateOf("") }
    var title by remember { mutableStateOf("") }
    var body by remember { mutableStateOf("") }
    var clickUrl by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf(false) }
    var message by remember { mutableStateOf<String?>(null) }
    val plans = listOf(AdPlan("7d", "1 Hafta", 7, 999, "masa10_ad_7d"), AdPlan("30d", "1 Ay", 30, 1999, "masa10_ad_30d"))
    AlertDialog(onDismissRequest = { if (!busy) onClose() }, title = { Text("📢 Reklamını Ver", fontWeight = FontWeight.Black) }, text = {
        Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("Reklamın önce ödeme ile alınır, sonra admin onayına düşer. Onaylandığı anda süre başlar.", color = TextMuted, fontSize = 12.sp)
            plans.forEach { plan ->
                Surface(Modifier.fillMaxWidth().clickable { selected = plan }, color = if (selected.id == plan.id) Purple.copy(alpha = .18f) else Card, shape = RoundedCornerShape(16.dp)) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        RadioButton(selected.id == plan.id, onClick = { selected = plan })
                        Column(Modifier.weight(1f)) { Text(plan.title, fontWeight = FontWeight.Bold); Text("${plan.days} gün yayın", color = TextMuted, fontSize = 11.sp) }
                        Text("${plan.priceTl} TL", color = Gold, fontWeight = FontWeight.Black)
                    }
                }
            }
            OutlinedTextField(advertiser, { advertiser = it }, label = { Text("İşletme / reklam adı") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(title, { title = it.take(80) }, label = { Text("Reklam başlığı") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(body, { body = it.take(280) }, label = { Text("Reklam açıklaması") }, minLines = 2, maxLines = 4, modifier = Modifier.fillMaxWidth())
            OutlinedTextField(clickUrl, { clickUrl = it.take(500) }, label = { Text("Tıklama bağlantısı (opsiyonel)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            message?.let { Text(it, color = if (it.startsWith("Başarılı")) Color(0xFF22C55E) else MaterialTheme.colorScheme.error, fontSize = 12.sp) }
        }
    }, confirmButton = {
        Button(enabled = !busy && advertiser.isNotBlank() && title.isNotBlank() && body.isNotBlank(), onClick = {
            busy = true; message = "Google Play ödeme ekranı açılıyor…"
            adBillingManager.buy(selected.productId, { productId, token, orderId ->
                functions.getHttpsCallable("submitSponsoredCampaign").call(mapOf(
                    "productId" to productId, "purchaseToken" to token, "orderId" to orderId, "planId" to selected.id,
                    "advertiserName" to advertiser.trim(), "title" to title.trim(), "body" to body.trim(), "clickUrl" to clickUrl.trim(), "priceTl" to selected.priceTl
                )).addOnSuccessListener {
                    busy = false; message = "Başarılı! Ödeme alındı. Reklamın admin onayına gönderildi."
                }.addOnFailureListener { busy = false; message = "Ödeme alındı ancak başvuru gönderilemedi: ${it.localizedMessage}" }
            }, { busy = false; message = "Ödeme başlatılamadı: $it" })
        }, colors = ButtonDefaults.buttonColors(containerColor = Orange)) { Text(if (busy) "İşleniyor…" else "Öde ve Başvur • ${selected.priceTl} TL") }
    }, dismissButton = { TextButton(enabled = !busy, onClick = onClose) { Text("Vazgeç") } })
}

private data class SponsoredCampaign(
    val id: String,
    val title: String,
    val body: String,
    val advertiserName: String,
    val icon: String,
    val clickUrl: String
)

@Composable
private fun HouseSponsoredCard(onClick: () -> Unit) {
    Surface(Modifier.fillMaxWidth().padding(horizontal = 14.dp), color = Card, shape = RoundedCornerShape(22.dp)) {
        Row(Modifier.clickable(onClick = onClick).padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(54.dp).clip(RoundedCornerShape(17.dp)).background(Brush.linearGradient(listOf(Purple, Pink, Orange))), contentAlignment = Alignment.Center) { Text("10", color = Color.White, fontWeight = FontWeight.Black, fontSize = 19.sp) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("SPONSORLU • MASA10", color = Gold, fontSize = 10.sp, fontWeight = FontWeight.Black)
                Text("Masa10'a katıl ✨", fontSize = 17.sp, fontWeight = FontWeight.Black)
                Text("10 kişi. 20 dakika. Gerçek sohbet.", color = TextMuted, fontSize = 12.sp)
            }
            Icon(Icons.Default.ChevronRight, null, tint = TextMuted)
        }
    }
}

@Composable
private fun SponsoredCampaignCard(campaign: SponsoredCampaign) {
    val context = androidx.compose.ui.platform.LocalContext.current
    val functions = FirebaseFunctions.getInstance()
    LaunchedEffect(campaign.id) { functions.getHttpsCallable("logSponsoredImpression").call(mapOf("campaignId" to campaign.id)) }
    Surface(Modifier.fillMaxWidth().padding(horizontal = 14.dp), color = Card, shape = RoundedCornerShape(22.dp)) {
        Row(Modifier.clickable {
            functions.getHttpsCallable("logSponsoredClick").call(mapOf("campaignId" to campaign.id))
            if (campaign.clickUrl.isNotBlank()) runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(campaign.clickUrl))) }
        }.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(54.dp).clip(RoundedCornerShape(17.dp)).background(Purple.copy(alpha = .2f)), contentAlignment = Alignment.Center) { Text(campaign.icon, fontSize = 24.sp) }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f)) {
                Text("SPONSORLU • ${campaign.advertiserName}", color = Gold, fontSize = 10.sp, fontWeight = FontWeight.Black)
                Text(campaign.title, fontSize = 17.sp, fontWeight = FontWeight.Black)
                Text(campaign.body, color = TextMuted, fontSize = 12.sp, maxLines = 2, overflow = TextOverflow.Ellipsis)
            }
            Icon(Icons.Default.OpenInNew, null, tint = TextMuted)
        }
    }
}

@Composable
private fun NativeAdCard() {
    var adViewRef by remember { mutableStateOf<NativeAdView?>(null) }
    DisposableEffect(Unit) { onDispose { adViewRef?.destroy() } }
    Surface(Modifier.fillMaxWidth().padding(horizontal = 14.dp), color = Card, shape = RoundedCornerShape(22.dp)) {
        Column(Modifier.padding(8.dp)) {
            Text("SPONSORLU", color = TextMuted, fontSize = 9.sp, fontWeight = FontWeight.Black, modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp))
            AndroidView(
                modifier = Modifier.fillMaxWidth().heightIn(min = 92.dp),
                factory = { context ->
                    NativeAdView(context).apply {
                        adViewRef = this
                        val root = LinearLayout(context).apply {
                            orientation = LinearLayout.HORIZONTAL
                            gravity = Gravity.CENTER_VERTICAL
                            setPadding(14, 10, 14, 10)
                        }
                        val icon = TextView(context).apply { text = "📢"; textSize = 28f; gravity = Gravity.CENTER }
                        val textCol = LinearLayout(context).apply { orientation = LinearLayout.VERTICAL; setPadding(12, 0, 8, 0) }
                        val headline = TextView(context).apply { textSize = 16f; setTypeface(typeface, android.graphics.Typeface.BOLD) }
                        val body = TextView(context).apply { textSize = 12f; setTextColor(android.graphics.Color.GRAY); maxLines = 2 }
                        val cta = TextView(context).apply { textSize = 12f; setTypeface(typeface, android.graphics.Typeface.BOLD) }
                        textCol.addView(headline, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                        textCol.addView(body, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                        textCol.addView(cta, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                        root.addView(icon, LinearLayout.LayoutParams(48, 48))
                        root.addView(textCol, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
                        addView(root, FrameLayout.LayoutParams(-1, -2))
                        headlineView = headline
                        bodyView = body
                        callToActionView = cta
                    }
                },
                update = { adView ->
                    if (adView.tag == null) {
                        adView.tag = "loading"
                        val loader = AdLoader.Builder(adView.context, "ca-app-pub-3940256099942544/2247696110")
                            .forNativeAd { ad ->
                                adView.setNativeAd(ad)
                                (adView.headlineView as? TextView)?.text = ad.headline
                                (adView.bodyView as? TextView)?.text = ad.body ?: ""
                                (adView.callToActionView as? TextView)?.text = ad.callToAction ?: "Daha fazla"
                            }
                            .withNativeAdOptions(NativeAdOptions.Builder().build())
                            .build()
                        loader.loadAd(AdRequest.Builder().build())
                    }
                }
            )
        }
    }
}

private data class FeedPost(
    val id: String, val uid: String, val displayName: String, val text: String, val createdAt: Timestamp?,
    val likeCount: Int, val likedByMe: Boolean, val commentCount: Int = 0, val repostCount: Int = 0, val hashtags: List<String> = emptyList()
)

@Composable
private fun FeedPostCard(post: FeedPost, onProfile: () -> Unit, onHashtag: (String) -> Unit, onLike: () -> Unit, onComment: () -> Unit, onRepost: () -> Unit) {
    Surface(Modifier.fillMaxWidth().padding(horizontal = 16.dp), color = Card, shape = RoundedCornerShape(20.dp)) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Surface(shape = CircleShape, color = Purple.copy(alpha = .2f), modifier = Modifier.clickable(onClick = onProfile)) {
                    Text(post.displayName.take(1).uppercase(), modifier = Modifier.padding(11.dp), fontWeight = FontWeight.Bold)
                }
                Spacer(Modifier.width(10.dp)); Column(Modifier.weight(1f).clickable(onClick = onProfile)) { Text(post.displayName, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis); Text("Masa10 Türkiye", color = TextMuted, fontSize = 11.sp) }
                Text("…", color = TextMuted, fontSize = 22.sp)
            }
            Spacer(Modifier.height(12.dp))
            Text(post.text, fontSize = 16.sp, lineHeight = 23.sp)
            if (post.hashtags.isNotEmpty()) { Spacer(Modifier.height(8.dp)); Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) { post.hashtags.take(4).forEach { tag -> AssistChip(onClick = { onHashtag("#$tag") }, label = { Text("#$tag") }) } } }
            Spacer(Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onLike) { Icon(if (post.likedByMe) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null, tint = if (post.likedByMe) Pink else TextMuted) }
                Text("${post.likeCount}", color = TextMuted, fontSize = 12.sp)
                IconButton(onClick = onComment) { Icon(Icons.Default.ChatBubbleOutline, null, tint = TextMuted) }
                Text("${post.commentCount}", color = TextMuted, fontSize = 12.sp)
                IconButton(onClick = onRepost) { Icon(Icons.Default.Repeat, null, tint = TextMuted) }
                Text("${post.repostCount}", color = TextMuted, fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun CommentSheet(postId: String, onClose: () -> Unit) {
    val db = FirebaseFirestore.getInstance(); val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return
    var input by remember { mutableStateOf("") }; var comments by remember { mutableStateOf<List<Pair<String,String>>>(emptyList()) }
    DisposableEffect(postId) {
        val reg = db.collection("posts").document(postId).collection("comments").orderBy("createdAt", Query.Direction.ASCENDING).limit(100)
            .addSnapshotListener { snap, _ -> comments = snap?.documents?.map { it.id to (it.getString("text") ?: "") } ?: emptyList() }
        onDispose { reg.remove() }
    }
    Surface(Modifier.fillMaxWidth(), color = Card, shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp)) {
        Column(Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) { Text("Yorumlar", fontSize = 20.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f)); IconButton(onClick = onClose) { Icon(Icons.Default.Close, null) } }
            LazyColumn(Modifier.heightIn(max = 280.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { items(comments) { (_, t) -> Surface(color = Bg, shape = RoundedCornerShape(14.dp)) { Text(t, Modifier.padding(12.dp)) } } }
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(input, { if (it.length <= 280) input = it }, modifier = Modifier.weight(1f), placeholder = { Text("Yorum yaz…") }, singleLine = true)
                IconButton(onClick = { val t=input.trim(); if(t.isNotEmpty()){ FirebaseFunctions.getInstance().getHttpsCallable("addPostComment").call(mapOf("postId" to postId, "text" to t)); input="" } }) { Icon(Icons.Default.Send, null) }
            }
        }
    }
}

@Composable
private fun UserProfileScreen(uid: String, onBack: () -> Unit) {
    val currentUid = FirebaseAuth.getInstance().currentUser?.uid ?: ""
    val db = FirebaseFirestore.getInstance()
    val functions = FirebaseFunctions.getInstance()
    var name by remember { mutableStateOf("Masa10 Kullanıcısı") }
    var bio by remember { mutableStateOf("Masa10'da güzel sohbetlerin peşinde ✨") }
    var postCount by remember { mutableIntStateOf(0) }
    var followers by remember { mutableIntStateOf(0) }
    var following by remember { mutableIntStateOf(0) }
    var isFollowing by remember { mutableStateOf(false) }
    var profilePosts by remember { mutableStateOf<List<FeedPost>>(emptyList()) }
    var loading by remember { mutableStateOf(true) }

    LaunchedEffect(uid) {
        functions.getHttpsCallable("getPublicProfile").call(mapOf("uid" to uid)).addOnSuccessListener { result ->
            val data = result.data as? Map<*, *> ?: return@addOnSuccessListener
            name = data["displayName"] as? String ?: name
            bio = data["bio"] as? String ?: bio
            postCount = (data["postCount"] as? Number)?.toInt() ?: 0
            followers = (data["followers"] as? Number)?.toInt() ?: 0
            following = (data["following"] as? Number)?.toInt() ?: 0
            isFollowing = data["isFollowing"] as? Boolean ?: false
            loading = false
        }.addOnFailureListener { loading = false }
    }
    DisposableEffect(uid) {
        val reg = db.collection("posts").whereEqualTo("uid", uid).orderBy("createdAt", Query.Direction.DESCENDING).limit(50)
            .addSnapshotListener { snap, _ ->
                profilePosts = snap?.documents?.map { d ->
                    val likedBy = (d["likedBy"] as? List<*>)?.filterIsInstance<String>() ?: emptyList()
                    FeedPost(d.id, uid, name, d.getString("text") ?: "", d.getTimestamp("createdAt"),
                        (d.getLong("likeCount") ?: 0).toInt(), currentUid in likedBy,
                        (d.getLong("commentCount") ?: 0).toInt(), (d.getLong("repostCount") ?: 0).toInt(),
                        (d["hashtags"] as? List<*>)?.filterIsInstance<String>() ?: emptyList())
                } ?: emptyList()
            }
        onDispose { reg.remove() }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 12.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) }
            Text("Profil", fontSize = 21.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
            Icon(Icons.Default.MoreVert, null, tint = TextMuted)
        }
        LazyColumn(contentPadding = PaddingValues(bottom = 28.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            item {
                Box(Modifier.fillMaxWidth().height(112.dp).background(Brush.linearGradient(listOf(Purple, Pink, Orange)))) {
                    Text("MASA10", Modifier.align(Alignment.BottomStart).padding(18.dp), color = Color.White.copy(alpha=.8f), fontSize = 12.sp, fontWeight = FontWeight.Black)
                }
                Column(Modifier.padding(horizontal = 18.dp)) {
                    Spacer(Modifier.height(4.dp))
                    Row(verticalAlignment = Alignment.Bottom) {
                        Box(Modifier.size(88.dp).clip(CircleShape).background(Bg).padding(5.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Purple, Pink))), contentAlignment = Alignment.Center) {
                            Text(name.take(1).uppercase(), fontSize = 34.sp, fontWeight = FontWeight.Black, color = Color.White)
                        }
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) { Text(name, fontSize = 23.sp, fontWeight = FontWeight.Black); Text("Masa10 kullanıcısı", color = TextMuted, fontSize = 12.sp) }
                    }
                    Spacer(Modifier.height(12.dp))
                    Text(bio, color = TextMain, fontSize = 14.sp)
                    Spacer(Modifier.height(14.dp))
                    if (uid != currentUid) {
                        Button(onClick = { functions.getHttpsCallable("toggleFollow").call(mapOf("targetUid" to uid)).addOnSuccessListener { r -> val d=r.data as? Map<*,*>; isFollowing=d?.get("following") as? Boolean ?: isFollowing; followers=(d?.get("followers") as? Number)?.toInt() ?: followers } }, modifier=Modifier.fillMaxWidth(), shape=RoundedCornerShape(14.dp), colors=ButtonDefaults.buttonColors(containerColor=if(isFollowing) Card else Purple)) {
                            Icon(if(isFollowing) Icons.Default.PersonRemove else Icons.Default.PersonAdd, null); Spacer(Modifier.width(8.dp)); Text(if(isFollowing) "Takibi Bırak" else "Takip Et", fontWeight=FontWeight.Bold)
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    Surface(Modifier.fillMaxWidth(), color=Card, shape=RoundedCornerShape(20.dp)) {
                        Row(Modifier.fillMaxWidth().padding(vertical=16.dp), horizontalArrangement=Arrangement.SpaceEvenly) {
                            ProfileStat("$postCount", "Gönderi"); ProfileStat("$followers", "Takipçi"); ProfileStat("$following", "Takip")
                        }
                    }
                }
            }
            item { Text("Gönderiler", Modifier.padding(horizontal=18.dp, vertical=4.dp), fontSize=18.sp, fontWeight=FontWeight.Black) }
            if (profilePosts.isEmpty() && !loading) item { Surface(Modifier.fillMaxWidth().padding(horizontal=18.dp), color=Card, shape=RoundedCornerShape(20.dp)) { Column(Modifier.padding(24.dp), horizontalAlignment=Alignment.CenterHorizontally) { Text("✨", fontSize=30.sp); Text("Henüz gönderi yok", fontWeight=FontWeight.Bold); Text("İlk paylaşım burada görünecek.", color=TextMuted, fontSize=12.sp) } } }
            items(profilePosts, key={it.id}) { post -> FeedPostCard(post, onProfile={}, onHashtag={}, onLike={functions.getHttpsCallable("togglePostLike").call(mapOf("postId" to post.id))}, onComment={}, onRepost={functions.getHttpsCallable("toggleRepost").call(mapOf("postId" to post.id))}) }
        }
    }
}

@Composable
private fun ProfileStat(value: String, label: String) { Column(horizontalAlignment = Alignment.CenterHorizontally) { Text(value, fontWeight = FontWeight.Black, fontSize = 18.sp); Text(label, color = TextMuted, fontSize = 11.sp) } }

@Composable
private fun MessagesScreen(onBack: () -> Unit) {
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text("Mesajlar", fontSize = 28.sp, fontWeight = FontWeight.Black, modifier = Modifier.weight(1f))
            IconButton(onClick = onBack) { Icon(Icons.Default.Close, null) }
        }
        Surface(Modifier.fillMaxWidth().padding(horizontal = 16.dp), color = Card, shape = RoundedCornerShape(20.dp)) {
            Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(48.dp).clip(CircleShape).background(Purple.copy(alpha = .18f)), contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Favorite, null, tint = Pink)
                }
                Spacer(Modifier.width(14.dp))
                Column {
                    Text("Eşleşmelerin ve özel sohbetlerin", fontWeight = FontWeight.Bold)
                    Text("Birisiyle eşleştiğinde sohbetin burada görünecek.", color = TextMuted, fontSize = 12.sp)
                }
            }
        }
        Spacer(Modifier.height(28.dp))
        Column(Modifier.fillMaxWidth().padding(32.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text("💬", fontSize = 48.sp)
            Spacer(Modifier.height(12.dp))
            Text("Henüz mesajın yok", fontSize = 20.sp, fontWeight = FontWeight.Black)
            Spacer(Modifier.height(6.dp))
            Text("Keşfet'te güzel bir sohbet başlat,
eşleştiğin kişilerle burada devam et.", color = TextMuted, fontSize = 13.sp)
        }
    }
}

@Composable
private fun NotificationsScreen(onBack: () -> Unit) {
    val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return
    val db = FirebaseFirestore.getInstance()
    var notifications by remember { mutableStateOf<List<Pair<String,String>>>(emptyList()) }
    DisposableEffect(uid) {
        val reg = db.collection("users").document(uid).collection("notifications").orderBy("createdAt", Query.Direction.DESCENDING).limit(50)
            .addSnapshotListener { snap, _ ->
                notifications = snap?.documents?.map { (it.getString("title") ?: "Masa10") to (it.getString("body") ?: "") } ?: emptyList()
                snap?.documents?.filter { it.getBoolean("read") != true }?.forEach { doc ->
                    doc.reference.update("read", true)
                }
            }
        onDispose { reg.remove() }
    }
    Column(Modifier.fillMaxSize()) {
        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment=Alignment.CenterVertically) { IconButton(onClick=onBack){Icon(Icons.Default.ArrowBack,null)}; Text("Bildirimler", fontSize=22.sp, fontWeight=FontWeight.Black) }
        LazyColumn(contentPadding=PaddingValues(16.dp), verticalArrangement=Arrangement.spacedBy(10.dp)) {
            if(notifications.isEmpty()) item { Surface(Modifier.fillMaxWidth(), color=Card, shape=RoundedCornerShape(20.dp)){Column(Modifier.padding(28.dp), horizontalAlignment=Alignment.CenterHorizontally){Text("🔔",fontSize=34.sp);Text("Bildirim yok",fontWeight=FontWeight.Bold);Text("Yeni etkileşimlerin burada görünecek.",color=TextMuted,fontSize=12.sp)}} }
            items(notifications) { (title, body) -> Surface(Modifier.fillMaxWidth(), color=Card, shape=RoundedCornerShape(18.dp)){Row(Modifier.padding(16.dp),verticalAlignment=Alignment.CenterVertically){Surface(shape=CircleShape,color=Purple.copy(alpha=.18f)){Icon(Icons.Default.Notifications,null,tint=Purple,modifier=Modifier.padding(10.dp))};Spacer(Modifier.width(12.dp));Column{Text(title,fontWeight=FontWeight.Bold);Text(body,color=TextMuted,fontSize=12.sp)}}} }
        }
    }
}

private data class TableState(val id: String?, val status: String, val count: Int, val size: Int, val endAt: Timestamp?, val topic: String, val pool: Int, val names: List<String>)
private data class ChatMessage(val id: String, val uid: String, val name: String, val text: String, val createdAt: Timestamp?)

@Composable
private fun TableScreen(onBack: () -> Unit) {
    val uid = FirebaseAuth.getInstance().currentUser?.uid ?: return
    val db = FirebaseFirestore.getInstance(); val functions = FirebaseFunctions.getInstance()
    var table by remember { mutableStateOf<TableState?>(null) }
    var loading by remember { mutableStateOf(true) }
    var error by remember { mutableStateOf<String?>(null) }
    var input by remember { mutableStateOf("") }
    var messages by remember { mutableStateOf<List<ChatMessage>>(emptyList()) }
    var joining by remember { mutableStateOf(false) }
    val waitingPoems = remember { listOf(
        "Bazı insanlar hayatımıza,\ntam zamanında çıkar.",
        "Belki de bugün tanışacağın biri,\nyarının güzel hikâyesidir.",
        "Bazen bir sohbet,\nkoca bir günün rengini değiştirir.",
        "Yeni bir insan,\nyeni bir ihtimal demektir.",
        "Güzel sohbetler tesadüfen başlar,\ngüzel dostluklara dönüşür.",
        "Bir masada on kişi olabilir,\nama bazen tek bir sohbet yeter.",
        "Bugün burada bekliyorsun,\nbelki de güzel bir karşılaşma yakında."
    ) }
    var poemIndex by remember { mutableIntStateOf(0) }
    LaunchedEffect(table?.id) {
        while (table?.id == null) {
            delay(5000)
            poemIndex = (poemIndex + 1) % waitingPoems.size
        }
    }

    fun join() {
        joining = true; error = null
        functions.getHttpsCallable("joinTable").call().addOnSuccessListener { joining = false }
            .addOnFailureListener { joining = false; error = it.localizedMessage }
    }
    LaunchedEffect(Unit) { join() }

    var activeTableId by remember { mutableStateOf<String?>(null) }
    DisposableEffect(Unit) {
        val qReg = db.collection("matchmaking").document("queue").addSnapshotListener { snap, _ ->
            val members = snap?.get("members") as? Map<*, *>
            val count = members?.size ?: 0
            val names = members?.values?.mapNotNull { (it as? Map<*, *>)?.get("displayName") as? String } ?: emptyList()
            if (count > 0 && activeTableId == null) table = TableState(null, "waiting", count, if (count < 40) 5 else 10, null, "Masa dolunca sohbet başlayacak.", 0, names)
            loading = false
        }
        val uReg = db.collection("users").document(uid).addSnapshotListener { snap, _ ->
            val active = snap?.getString("activeTableId")
            activeTableId = if (active == "QUEUE") null else active
            if (active == null) loading = false
        }
        onDispose { qReg.remove(); uReg.remove() }
    }

    DisposableEffect(activeTableId) {
        val id = activeTableId ?: return@DisposableEffect onDispose { }
        val reg = db.collection("tables").document(id).addSnapshotListener { ts, _ ->
            if (ts?.exists() == true) {
                val p = ts.data?.get("participants") as? Map<*, *>
                val names = p?.values?.mapNotNull { (it as? Map<*, *>)?.get("displayName") as? String } ?: emptyList()
                table = TableState(id, ts.getString("status") ?: "active", ts.getLong("participantCount")?.toInt() ?: p?.size ?: 0,
                    ts.getLong("tableSize")?.toInt() ?: 10, ts.getTimestamp("endAt"), ts.getString("topic") ?: "", ts.getLong("extensionPool")?.toInt() ?: 0, names)
            }
        }
        onDispose { reg.remove() }
    }

    DisposableEffect(table?.id) {
        val id = table?.id ?: return@DisposableEffect onDispose { }
        val reg = db.collection("tables").document(id).collection("messages").orderBy("createdAt", Query.Direction.ASCENDING).limitToLast(100)
            .addSnapshotListener { snap, _ ->
                messages = snap?.documents?.map { d -> ChatMessage(d.id, d.getString("uid") ?: "", d.getString("name") ?: "Kullanıcı", d.getString("text") ?: "", d.getTimestamp("createdAt")) } ?: emptyList()
            }
        onDispose { reg.remove() }
    }

    var remaining by remember { mutableLongStateOf(0L) }
    LaunchedEffect(table?.endAt) {
        while (true) {
            val end = table?.endAt?.toDate()?.time ?: break
            remaining = ((end - System.currentTimeMillis()).coerceAtLeast(0L) / 1000L)
            if (remaining <= 0) break
            delay(1000)
        }
    }

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) }
            Column(Modifier.weight(1f)) { Text(if (table?.id == null) "Masa bekleniyor" else "Masa #${table!!.id.take(6)}", fontWeight = FontWeight.Bold); Text("${table?.size ?: 10} kişilik sohbet", color = TextMuted, fontSize = 12.sp) }
            if (table?.id != null) Text("%02d:%02d".format(remaining / 60, remaining % 60), color = Orange, fontWeight = FontWeight.Bold)
        }

        if (table?.id == null) {
            Surface(Modifier.fillMaxWidth().padding(vertical = 12.dp), color = Card, shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(22.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(color = Purple)
                    Spacer(Modifier.height(14.dp)); Text("Masa10 seni eşleştiriyor…", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(8.dp)); Text("${table?.count ?: 0} / ${table?.size ?: 5} kişi hazır", color = TextMuted)
                    Spacer(Modifier.height(12.dp)); LinearProgressIndicator(progress = { ((table?.count ?: 0) / (table?.size ?: 5).toFloat()).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(22.dp));
                    AnimatedContent(targetState = poemIndex, label = "waitingPoem") { index ->
                        Surface(color = Color(0xFF171225), shape = RoundedCornerShape(18.dp), modifier = Modifier.fillMaxWidth()) {
                            Text(waitingPoems[index], modifier = Modifier.padding(18.dp), color = TextMain, fontSize = 17.sp, lineHeight = 25.sp, fontWeight = FontWeight.SemiBold)
                        }
                    }
                    Spacer(Modifier.height(12.dp)); Text("Beklerken güzel bir sohbet için doğru insanları buluyoruz.", color = TextMuted, fontSize = 12.sp)
                    error?.let { Spacer(Modifier.height(8.dp)); Text(it, color = MaterialTheme.colorScheme.error, fontSize = 12.sp) }
                    TextButton(onClick = { functions.getHttpsCallable("leaveQueue").call(); onBack() }) { Text("Beklemekten vazgeç") }
                }
            }
        } else {
            Surface(Modifier.fillMaxWidth().padding(vertical = 12.dp), color = Card, shape = RoundedCornerShape(22.dp)) {
                Column(Modifier.padding(18.dp)) {
                    Text("💬 Konu", color = Pink, fontWeight = FontWeight.Bold); Spacer(Modifier.height(6.dp)); Text(table!!.topic, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.height(14.dp)); LinearProgressIndicator(progress = { (table!!.pool / 100f).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth())
                    Spacer(Modifier.height(6.dp)); Text("Masa uzatma: ${table!!.pool} / ${if (table!!.size == 5) 50 else 100} jeton", color = TextMuted, fontSize = 12.sp)
                    Spacer(Modifier.height(10.dp)); Button(onClick = { functions.getHttpsCallable("extendTable").call(mapOf("tableId" to table!!.id)) }, colors = ButtonDefaults.buttonColors(containerColor = Orange), modifier = Modifier.fillMaxWidth()) { Text("🪙 10 jeton katkı yap") }
                }
            }
            LazyColumn(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                items(messages, key = { it.id }) { m ->
                    Surface(color = Card, shape = RoundedCornerShape(16.dp)) { Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) { Box(Modifier.size(40.dp).clip(CircleShape).background(Purple)); Spacer(Modifier.width(10.dp)); Column { Text(if (m.uid == uid) "Sen" else m.name, fontWeight = FontWeight.Bold); Text(m.text, color = TextMain) } } }
                }
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(input, { input = it }, placeholder = { Text("Mesaj yaz...") }, modifier = Modifier.weight(1f), singleLine = true)
                IconButton(onClick = {
                    val text = input.trim(); if (text.isEmpty() || table?.id == null) return@IconButton
                    val ref = db.collection("tables").document(table!!.id!!).collection("messages").document()
                    val me = FirebaseAuth.getInstance().currentUser?.email?.substringBefore("@") ?: "Kullanıcı"
                    ref.set(mapOf("uid" to uid, "name" to me, "text" to text, "createdAt" to FieldValue.serverTimestamp(), "likedBy" to emptyList<String>()))
                    input = ""
                }) { Icon(Icons.Default.Send, null) }
            }
        }
    }
}

@Composable
private fun CoinsScreen(onBack: () -> Unit) {
    Column(Modifier.fillMaxSize().padding(20.dp)) {
        IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) }; Text("Jetonlar", fontSize = 30.sp, fontWeight = FontWeight.Black); Text("Masa10 ekonomisinin merkezi", color = TextMuted)
        Spacer(Modifier.height(22.dp)); CoinPack("100 Jeton", "99,99 TL", false); CoinPack("200 Jeton", "149,99 TL", true); CoinPack("300 Jeton", "199,99 TL", false)
        Spacer(Modifier.height(18.dp)); Surface(color = Card, shape = RoundedCornerShape(22.dp)) { Column(Modifier.padding(18.dp)) { Text("🎬 Jeton Kazan", fontWeight = FontWeight.Bold, fontSize = 18.sp); Text("Ödüllü reklam izle → +5 jeton", color = TextMuted); Text("Günde en fazla 5 reklam.", color = TextMuted, fontSize = 12.sp) } }
    }
}

@Composable private fun CoinPack(name: String, price: String, popular: Boolean) { Surface(color = Card, shape = RoundedCornerShape(20.dp), modifier = Modifier.fillMaxWidth().padding(vertical = 5.dp)) { Row(Modifier.padding(18.dp), verticalAlignment = Alignment.CenterVertically) { Text("🪙", fontSize = 26.sp); Spacer(Modifier.width(12.dp)); Column(Modifier.weight(1f)) { Text(name, fontWeight = FontWeight.Bold); if (popular) Text("EN ÇOK TERCİH EDİLEN", color = Orange, fontSize = 10.sp, fontWeight = FontWeight.Bold) }; Text(price, color = Gold, fontWeight = FontWeight.Bold) } } }

@Composable private fun ProfileScreen(onBack: () -> Unit) { val user = FirebaseAuth.getInstance().currentUser; Column(Modifier.fillMaxSize().padding(20.dp)) { IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, null) }; Box(Modifier.size(88.dp).clip(CircleShape).background(Brush.linearGradient(listOf(Purple, Pink))), contentAlignment = Alignment.Center) { Text("M", fontSize = 38.sp, fontWeight = FontWeight.Black) }; Spacer(Modifier.height(12.dp)); Text(user?.email ?: "Masa10 kullanıcısı", fontSize = 24.sp, fontWeight = FontWeight.Black); Text("Yeni kullanıcı", color = TextMuted); Spacer(Modifier.height(24.dp)); Surface(color = Card, shape = RoundedCornerShape(20.dp)) { Column(Modifier.padding(18.dp)) { Text("⭐ VIP", fontWeight = FontWeight.Bold); Text("399 TL / ay • günlük +20 jeton • reklamsız", color = TextMuted) } } } }
