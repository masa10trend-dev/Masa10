# Masa10 - GitHub Build Ready

This package is prepared for GitHub Actions APK building.

The repository root contains the Android project directly (no nested project folder).
The workflow installs Gradle 9.6.0 and Android SDK 37, builds the debug APK, and uploads it as an artifact.
